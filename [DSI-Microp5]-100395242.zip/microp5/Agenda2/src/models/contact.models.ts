export interface Contact{

    key?: string;// maneja´ra el id cuando se utiliza firebase
    nombre: string;
    organizacion: string;
    movil: string; 
    correo: string; 
}