import { Contact } from "../models/contact.models";

export class ContactService{

    private contacts: Contact[]=[{"nombre":"Andres", "organizacion":"UC3M","movil":"666666666", correo:"andres@example.com"}];
    constructor(){
        // empty. default contrusctor
    }
    addContact (value:Contact){
        this.contacts.push(value);
    }

    getContacts(){
        return this.contacts;
    }

    updateContact(value: Contact){

    }

    removeContact(value: Contact){

    }
}
