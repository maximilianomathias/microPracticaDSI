import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agenda-electronica',
  templateUrl: './agenda-electronica.page.html',
  styleUrls: ['./agenda-electronica.page.scss'],
})
export class AgendaElectronicaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
