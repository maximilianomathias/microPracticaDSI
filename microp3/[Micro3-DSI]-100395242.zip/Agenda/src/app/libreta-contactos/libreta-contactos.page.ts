import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-libreta-contactos',
  templateUrl: './libreta-contactos.page.html',
  styleUrls: ['./libreta-contactos.page.scss'],
})
export class LibretaContactosPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
