import { Component } from '@angular/core';

import { Platform } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html'
})
export class AppComponent {
  public appPages = [
    {
      title: 'Home', 
      url:'/home', 
      icon:'home'
    },
    {
      title: 'Lista de contactos',
      url: '/libreta-contactos',
      icon: 'contact'
    },
    {
      title: 'Agenda electronica',
      url: '/agenda-electronica',
      icon: 'calendar'
    },
    {
      title: 'Acerca de', 
      url: '/acerca-de',
      icon: 'list'
    },
  ];

  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar
  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }
}
